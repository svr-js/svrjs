var fs = require("fs");
var os = require("os");
function Mod() {}
Mod.prototype.callback = function callback(req, res, serverconsole, responseEnd, href, ext, uobject, search, defaultpage, users, page404, head, foot, fd, elseCallback, configJSON) {
    return function () {
        if (ext == "html" && fs.existsSync("." + req.url) && fs.lstatSync("." + req.url).isFile()) fs.writeFileSync("views.txt", (parseInt(fs.readFileSync("views.txt")) + 1).toString());
        if (fs.existsSync("." + req.url) && fs.lstatSync("." + req.url).isDirectory() && fs.existsSync(("." + req.url + "/index.html").replace(/\/\//g,"/"))) fs.writeFileSync("views.txt", (parseInt(fs.readFileSync("views.txt")) + 1).toString());
        if (href == "/hview") {
                        try {
                            res.writeHead(200, "Recieved Content", {
                                'Server': 'SVR.JS/' + configJSON.version + ' (' + os.platform()[0].toUpperCase() + os.platform().slice(1) + ')'
                            });
                            res.write("<xml></xml>");
                            serverconsole.resmessage("Client successfully recievied content.");
                            fs.writeFileSync("hviews.txt", (parseInt(fs.readFileSync("hviews.txt")) + 1).toString());
                            res.end();
                        } catch (ex) {
                            var cheaders = (configJSON.customHeaders == undefined ? [] : configJSON.customHeaders);
                            cheaders['Server'] = 'SVR.JS/' + configJSON.version + ' (' + os.platform()[0].toUpperCase() + os.platform().slice(1) + ')';
                            cheaders['content-type'] = 'text/html; charset=utf-8';
                            res.writeHead(500, "Internal Server Error", cheaders);
                            res.write("<html><head><title>500 Internal Server Error</title></head><body><h1>500 Internal Server Error</h1><p>A server had unexcepted execption. Below, stack of the error is shown: </p><code>" + ex.stack.replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>").replace(/\r/g, "<br/>").replace(/ /g, "&nbsp;") + "</code><p>Please contact with developer/administrator of the website.</p><p style=\"font-style: italic; font-weight: normal;\">SVR.JS " + configJSON.version + ' (' + os.platform()[0].toUpperCase() + os.platform().slice(1) + '; Node.JS/' + process.version + ')' + (req.headers.host == undefined ? "" : " on " + req.headers.host) + "</p></body></html>");
                            res.end();
                            serverconsole.errmessage("Client fails recieving content.");
                        }
                        return;
                    } else {
                      elseCallback();
                   }
    }
}
module.exports = Mod;
